# JUJU — FIRST WORLD

This folder is ready for GitHub Pages.

## Upload
1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Go to Settings → Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Select the `main` branch and `/ (root)`.
6. Save.
7. Open the GitHub Pages URL shown there.

The game is self-contained in `index.html`, so no build step is required.
